import img1 from '../img/img1.jpg';
import img2 from '../img/img2.jpg';
import img3 from '../img/img3.jpg';
import img4 from '../img/img4.jpg';
import img5 from '../img/img5.jpg';
import img6 from '../img/img6.jpg';

const Sdata = [
    {
        key: 1,
        ids: "1",
        imgurl:img1,
        name: "Olivia",
        mail:"olivi01@gmail.com"
    },
    {
        key: 2,
        ids: "2",
        imgurl:img2,
        name: "William",
        mail:"william45@gmail.com"
    },
    {
        key: 3,
        ids: "3",
        imgurl:img3,
        name: "Lucas",
        mail:"lucas4@gmail.com"
    },
    {
        key: 4,
        ids: "4",
        imgurl:img4,
        name: "James",
        mail:"James123@gmail.com"
    },
    {
        key: 5,
        ids: "5",
        imgurl:img5,
        name: "Eliza",
        mail:"eliza04@gmail.com"
    },
    {
        key: 6,
        ids: "6",
        imgurl:img6,
        name: "Jewel",
        mail:"jewel01@gmail.com"
    }
]
export default Sdata;